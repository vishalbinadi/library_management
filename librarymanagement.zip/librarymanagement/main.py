import datetime
from time import time,ctime,localtime
import os
class Library:
    def __init__(self, list, name):
        self.list = "list_of_books.txt"
        self.name = name
        self.books_dict = {}
        Id = 101
        with open(self.list) as bk:
            content=bk.readlines()

        for line in content:
            self.books_dict.update({str(Id):{"books_title":line.replace("\n",""),
            "lender_name": "","Issue_date":"","Status":"Available"}})
            Id = Id + 1



    def displayBooks(self):
         print("We have following books in our library")
         print("Books Id ","\t","Title")
         print("------------------------------------------------------")
         for key, value in self.books_dict.items():
             print(key, "\t\t", value.get("books_title"),"-[",value.get("Status"),"]")



    def lendBook(self):
        book_id = input("Enter book Id: ")
        current_date = datetime.datetime.now().strftime("%Y-%m_%d %H:%M:%S")
        if book_id in self.books_dict.keys():
            if not self.books_dict[book_id]["Status"]=="Available":
                print(f"This books is already issued to {self.books_dict[book_id]['lender_name']} \
                on {self.books_dict[book_id]['Issue_date']}")
                return self.lendBook()
            elif self.books_dict[book_id]['Status']=="Available":
                your_name=input("Enter your name: ")
                self.books_dict[book_id]['lender_name'] = your_name
                self.books_dict[book_id]['Issue_date'] = current_date
                self.books_dict[book_id]['Status'] = "Already Issued"
                print("Books Issued Successfully.........")

            else:
                print("Book Id not found!!!!")
                return self.lendBook()



    def addBook(self):

         new_book=input("enter books title: " )
         if new_book=="":
             return self.addBook()
         elif len(new_book)>25:
             print("Books title length is too long!! title length should be 20 chars")
             return self.addBook()
         else:
             with open(self.list,"a") as bk:
                 bk.writelines(f"{new_book}\n")
                 self.books_dict.update({str(int(max(self.books_dict))+1):{'books_title':new_book,'lender_name':"",
                 'Issue_date':"",'Status':"Available"}})
                 print(f"this books {new_book} has been added successfully!!!!")


    def returnBook(self):
        book_id= input("enter book id: ")
        if book_id in self.books_dict.keys():

            if self.books_dict[book_id]["Status"]=="Available":
                print("this book is already available in library. please check your book id")
                return self.returnBook()
            elif not self.books_dict[book_id]["Status"]=="Available":
                self.books_dict[book_id]['lender_name'] = ""
                self.books_dict[book_id]['Issue_date'] = ""
                self.books_dict[book_id]['Status'] = "Available"
                print("Successfully updated!!!!")
            else:
                print("book id not found")


    def penalty(self):
        n=int(input("Enter no of days of return book: "))
        if n<0:
            print("Invalid input")
        elif n>10:
            print(f"you have penalty of rupees: {(n-10)*3}")

        else:
            print("You have no penalty...............")


if __name__ == '__main__':
    anish = Library("list_of_books.txt","Anish's")

    while(True):
        print(f"...........Welcome to the {anish.name} library..........\n Enter your choice to continue")
        print("1. Display Books")
        print("2. Lend a Book")
        print("3. Add a Book")
        print("4. Return a Book")
        user_choice = input()
        if user_choice not in ['1','2','3','4']:
            print("Please enter a valid option")
            continue

        else:
            user_choice = int(user_choice)


        if user_choice == 1:
            print("\nyou selected : Display Books\n")
            anish.displayBooks()

        elif user_choice == 2:
            print("\nyou selected : Issue Books\n")
            anish.lendBook()


        elif user_choice == 3:
            print("\nyou selected : Add Books\n")
            anish.addBook()

        elif user_choice == 4:
            print("\nyou selected : Return Books\n")
            anish.penalty()
            anish.returnBook()


        else:
            print("Not a valid option")
        print("Press q to quit and c to continue")
        user_choice2 = ""

        while(user_choice2!="c" and user_choice2!="q"):
            user_choice2 = input()
            if user_choice2 == "q":
                exit()

            elif user_choice2 == "c":
                continue